import { createStore } from "vuex";

export default createStore({
  // 数据公共资源
  state() {
    return {
      // 设置初始值
      name: 'TAC阿萨',
      age: 20,
      numbers: 0,
      inctime: null
    }
  },
  // 修改数据
  mutations: {
    // 方法一不传参改名
    // 接收一个名为cname的事件
    cname(state) {
      // 获取公共资源中的name值，修改为赵六
      state.name = '赵六'
    },
    // 方法一传参数改名
    cuname(state, aname) {
      state.name = aname
    },
    // 方法二不传参改名
    namego(state) {
      state.name = '老刘'
    },
    // 方法二传参数改名
    unamego(state, aname) {
      if (!(aname.trim())) return alert('输入姓名')
      state.name = aname
    },
    // 点击增加年龄
    add(state) {
      state.age++
    },
    // 点击数字自增
    push(state, val) {
      state.numbers += val

    }
  },
  // 处理任务
  actions: {
    // incgo为点击数字自增
    incgo(context, val) {
      // 判定定时器是否存在
      if (context.state.inctime) return
      // 添加定时器
      context.state.inctime = setInterval(() => {
        context.commit('push', val)
      }, 500)
    },
    // incstop为点击停止自增
    incstop(state) {
      // 清除定时器
      clearInterval(state.state.inctime)
      // 让定时器为null
      state.state.inctime = null
      // console.log(state.state.inctime)
    }
  },
  // 
  modules: {},
  getters: {}
});
