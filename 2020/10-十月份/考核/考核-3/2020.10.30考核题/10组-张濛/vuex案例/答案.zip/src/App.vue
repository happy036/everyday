<template>
  <!-- <div id="app" class="one">
    <h2>我叫 {{ name }} ，今年 {{ age }} 岁</h2>
    <div>
      <span>请输入一个名字:</span>
      <input type="text" v-model.lazy="idname" />
    </div>
    <p>方法一实现更改姓名</p>
    <button @click="bynamego">不传参换名字</button>
    <button @click="byunamego">传参换名字</button>
    <p>方法二实现更改姓名</p>
    <button @click="namego">不传参换名字</button>
    <button @click="unamego(idname)" value="">传参换名字</button>
    <p>点击增加年龄</p>
    <button @click="add">点击增加年龄</button>
    <p>点击开始按钮数字自增，点击停止按钮数字停止增加</p>
    <p>自动变更的数字 {{ numbers }}</p>
    <button @click="incgo(2)">开始自增</button>
    <button @click="incstop">停止自增</button>
  </div> -->

  <div id="app" class="one">
    <h2>我叫  ，今年  岁</h2>
    <div>
      <span>请输入一个名字:</span>
      <input type="text"/>
    </div>
    <p>方法一实现更改姓名</p>
    <button>不传参换名字</button>
    <button>传参换名字</button>
    <p>方法二实现更改姓名</p>
    <button>不传参换名字</button>
    <button value="">传参换名字</button>
    <p>点击增加年龄</p>
    <button>点击增加年龄</button>
    <p>点击开始按钮数字自增，点击停止按钮数字停止增加</p>
    <p>自动变更的数字 </p>
    <button>开始自增</button>
    <button>停止自增</button>
  </div>
</template>

<script>
// 接收store文件夹中index.js的方法
import { mapState, mapMutations, mapActions} from "vuex";

export default {
  data() {
    return {
      idname: ""
    };
  },
  computed: {
    // 接收store文件夹中的数据
    ...mapState(["name", "age","numbers"])
  },
  methods: {
    ////////// 方法一换名字
    // 不传参
    bynamego() {
      // 向store文件夹的index.js文件传入一个名为cname的事件
      this.$store.commit("cname");
    },
    // 传参
    byunamego() {
      // 判定姓名输入框不能为空
      if (!this.idname.trim()) return alert("请输入姓名");
      // 设置一个值接收输入框的参数
      let aname = this.idname;
      // 使用this.$store.commit方法，创建cuname，发送aname数据
      this.$store.commit("cuname", aname);
      // 清空输入框
      this.idname = "";
    },
    ////////// 方法二换名字(namego,unamego)
    // 点击年龄增加(add)
    ...mapMutations(["namego", "unamego", "add"]),
    // 点击数字开始自增,停止自增
    ...mapActions(['incgo','incstop'])
  }
};
</script>

<style>
.one {
  text-align: center;
}
button {
  margin: 0 5px;
}
</style>